# IT Effort Estimation Control Tower - User Manual

## 1. Framework upload

Open Framework Manager and download the existing template. Maintain the Excel tabs and upload the completed file.

Required tabs:

- ProgramMaster
- ProductMaster
- ScenarioBaseline
- ScopeQuestions
- DecisionRules
- WorkpackageRules
- RoleCost
- FrameworkVersions

When a new framework version is uploaded, the latest version can become active. Old versions remain visible but inactive.

## 2. Create a new estimate

Open New Estimation and follow the five steps.

### Step 1: Select template

Select program, product, framework version, project name, estimation code, number of sets, start date and end date.

The request record name follows:

`Program + Product + Estimation Code`

### Step 2: Answer scope

The question list is loaded from the active framework. Answers determine the scenario through decision rules.

### Step 3: Calculate effort

The system calculates baseline and estimated MD by work package and role. Users may edit, add or delete work package lines. All changes are compared with the baseline.

### Step 4: Plan demand

The system proposes a role timeline based on start/end date and work package rules. Users can adjust role demand by period.

### Step 5: Approve

If the request is roll-out with enhancement or more than 20% above baseline, special approval is required. Otherwise submission is automatically approved.

## 3. Dashboard

The dashboard shows total effort, standard effort, enhancement effort and testing effort. It also lists project requests with scenario, total MD, cost, baseline variance and status.

## 4. Framework Manager

Use this page to view active scenario baselines, working package details and trend analysis. You can also download/upload framework Excel templates.

## 5. Master Data

Use Master Data to review active and old versions. Inactive versions cannot be selected for new estimates but are retained for audit.
