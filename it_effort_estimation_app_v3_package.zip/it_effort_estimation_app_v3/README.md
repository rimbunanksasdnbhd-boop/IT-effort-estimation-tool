# IT Effort Estimation Control Tower

Production-style front-end mock-up and static coding package for an IT effort estimation application.

## What is included

- `index.html` — full HTML/CSS/JavaScript mock-up.
- `data/sample-framework.json` — demo framework data structure.
- `it_effort_estimation_template_v2.xlsx` — upload template for master data and framework rules.
- `docs/USER_MANUAL.md` — user guide.

## Core modules

1. Executive Dashboard
2. New Estimation: select template, answer scope, calculate effort, plan demand, approve
3. Request Workspace
4. Demand Plan
5. Approval Center
6. Framework Manager
7. Master Data

## Static hosting

### GitHub Pages

1. Create a new GitHub repository.
2. Upload all files in this package.
3. Go to Settings > Pages.
4. Select branch `main` and root folder.
5. Open the generated GitHub Pages URL.

### Azure Static Web Apps

1. Create Azure Static Web App.
2. Connect the GitHub repository.
3. Set app location to `/`.
4. Build command can be empty because this is a static HTML package.
5. Deploy.

### SAP BTP HTML5 Repository concept

1. Put this package into an HTML5 app module.
2. Add `xs-app.json` and route configuration if backend APIs are added.
3. Deploy through Cloud Foundry or managed app router.

## Future backend integration points

Replace demo arrays in `index.html` with APIs:

- `GET /api/frameworks/active?program=&product=`
- `POST /api/frameworks/upload`
- `POST /api/estimates`
- `GET /api/estimates/my-programs`
- `POST /api/estimates/{id}/submit`
- `POST /api/approvals/{id}/decision`

## Data model recommendation

Main entities:

- Program
- Product
- ScenarioBaseline
- ScopeQuestion
- DecisionRule
- WorkpackageRule
- RoleCost
- FrameworkVersion
- EstimateRequest
- EstimateWorkpackage
- DemandPlan
- ApprovalRule
- ApprovalHistory

## Approval logic

Special approval is triggered when:

- Scenario = Roll-out with enhancement, or
- Estimated effort is more than 20% above baseline.

Otherwise submit status becomes Approved directly.
